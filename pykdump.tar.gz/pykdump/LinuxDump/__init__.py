"""Crashlib Python API for CRASH Dumps Tool
"""
# Version number
__version__ = '0.3'

# Copyright notice string
__copyright__ = """\
(C) Copyright 2006-2015 Hewlett Packard Enterprise Development LP
Author: Alex Sidorenko <asid@hpe.com>
"""

from pykdump.API import *

