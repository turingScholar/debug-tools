# -*- coding: utf-8 -*-
# module LinuxDump.scsi
#
# --------------------------------------------------------------------
# (C) Copyright 2013-2020 Hewlett Packard Enterprise Development LP
# (C) Copyright 2014-2022 Red Hat, Inc.
#
# Authors: Alex Sidorenko <asid@hpe.com>
#          David Jeffery <djeffery@redhat.com>
#
# Contributors:
# - Milan P. Gandhi <mgandhi@redhat.com>
# - John Pittman <jpittman@redhat.com>
# - Nitin U. Yewale <nyewale@redhat.com>
#
# Many of the contributions to this package are inspired from the existing
# code in progs/scsishow.py program. The generic functions from scsishow.py
# program are moved to this file for better reusability. There will be
# separate modules added to process the HBA driver specific information.
#
# --------------------------------------------------------------------
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

from __future__ import print_function

__doc__ = '''
This is a package providing generic access to SCSI stuff
'''

from pykdump.API import *
from collections import (namedtuple, defaultdict, OrderedDict)
from LinuxDump.sysfs import *
from LinuxDump.kobjects import *
from LinuxDump.Time import j_delay

'''
Attached devices:
Host: scsi2 Channel: 03 Id: 00 Lun: 00
  Vendor: HP       Model: P420i            Rev: 3.54
  Type:   RAID                             ANSI  SCSI revision: 05
Host: scsi2 Channel: 00 Id: 00 Lun: 00
  Vendor: HP       Model: LOGICAL VOLUME   Rev: 3.54
  Type:   Direct-Access                    ANSI  SCSI revision: 05
'''

scmd_msg_byte = {
    0x00: "COMMAND_COMPLETE",    0x01: "EXTENDED_MESSAGE",
    0x02: "SAVE_POINTERS",       0x03: "RESTORE_POINTERS",
    0x04: "DISCONNECT",          0x05: "INITIATOR_ERROR",
    0x06: "ABORT_TASK_SET",      0x07: "MESSAGE_REJECT",
    0x08: "NOP",                 0x09: "MSG_PARITY_ERROR",
    0x0a: "LINKED_CMD_COMPLETE", 0x0b: "LINKED_FLG_CMD_COMPLETE",
    0x0c: "TARGET_RESET",        0x0d: "ABORT_TASK",
    0x0e: "CLEAR_TASK_SET",      0x0f: "INITIATE_RECOVERY",
    0x10: "RELEASE_RECOVERY",    0x16: "CLEAR_ACA",
    0x17: "LOGICAL_UNIT_RESET",  0x20: "SIMPLE_QUEUE_TAG",
    0x21: "HEAD_OF_QUEUE_TAG",   0x22: "ORDERED_QUEUE_TAG",
    0x23: "IGNORE_WIDE_RESIDUE", 0x24: "ACA",
    0x55: "QAS_REQUEST"
}

scmd_driver_byte = {
    0x00: "DRIVER_OK",      0x01: "DRIVER_BUSY",
    0x02: "DRIVER_SOFT",    0x03: "DRIVER_MEDIA",
    0x04: "DRIVER_ERROR",   0x05: "DRIVER_INVALID",
    0x06: "DRIVER_TIMEOUT", 0x07: "DRIVER_HARD",
    0x08: "DRIVER_SENSE"
}

scmd_status_byte = {
    0x0:  "SAM_STAT_GOOD",                 0x2:  "SAM_STAT_CHECK_CONDITION",
    0x4:  "SAM_STAT_CONDITION_MET",        0x8:  "SAM_STAT_BUSY",
    0x10: "SAM_STAT_INTERMEDIATE",         0x14: "SAM_STAT_INTERMEDIATE_CONDITION_MET",
    0x18: "SAM_STAT_RESERVATION_CONFLICT", 0x22: "SAM_STAT_COMMAND_TERMINATED",
    0x28: "SAM_STAT_TASK_SET_FULL",        0x30: "SAM_STAT_ACA_ACTIVE",
    0x40: "SAM_STAT_TASK_ABORTED"
}

scmd_host_byte = {
    0x0:  "DID_OK",                  0x1:  "DID_NO_CONNECT",
    0x2:  "DID_BUS_BUSY",            0x3:  "DID_TIME_OUT",
    0x4:  "DID_BAD_TARGET",          0x5:  "DID_ABORT",
    0x6:  "DID_PARITY",              0x7:  "DID_ERROR",
    0x8:  "DID_RESET",               0x9:  "DID_BAD_INTR",
    0x0a: "DID_PASSTHROUGH",         0x0b: "DID_SOFT_ERROR",
    0x0c: "DID_IMM_RETRY",           0x0d: "DID_REQUEUE",
    0x0e: "DID_TRANSPORT_DISRUPTED", 0x0f: "DID_TRANSPORT_FAILFAST",
    0x10: "DID_TARGET_FAILURE",      0x11: "DID_NEXUS_FAILURE",
    0x12: "DID_ALLOC_FAILURE",       0x13: "DID_MEDIUM_ERROR",
    0x14: "DID_TRANSPORT_MARGINAL"
}

opcode_table = {'0x0':'TUR', '0x03':'REQ-SENSE', '0x08':'READ(6)',\
                '0x0a':'WRITE(6)', '0x12':'INQUIRY', '0x16':'RESERVE(6)',\
                '0x17':'RELEASE(6)', '0x25':'READ-CAP(10)', '0x28':'READ(10)',\
                '0x2a':'WRITE(10)', '0x35':'SYNC CACHE', '0x41':'WR SAME',\
                '0x56':'RESERVE(10)', '0x57':'RELEASE(10)', '0x88':'READ(16)',\
                '0x8a':'WRITE(16)','0xa0':'REPORT LUNS', '0xa8':'READ(12)',\
                '0xaa':'WRITE(12)'}

def dprint(*args, **kwargs):
    if debug:
        print(*args, **kwargs)

def xarray_entry(xarray, index):
    node = xarray.xa_head
    if (not (long(node) & 2)):
        if index:
            return 0
        else:
            return node
    node = readSU("struct xa_node", node & ~3)
    if ((index >> node.shift) > 63):
        #raise IndexError('index bigger than xarray')
        return 0
    while (node):
        offset = (index >> node.shift) & 63
        node = node.slots[offset]
        if (not node or not (long(node) & 2)):
                return node
        node = readSU("struct xa_node", node & ~3)

# Return the name of module used by specific Scsi_Host (shost)
def get_hostt_module_name(shost):
    try:
        name = shost.hostt.module.name
    except:
        name = "unknown"
    return name

# ...........................................................................
#
# There are several ways to get lists of shosts/devices. We can get just
# Scsi_Host from 'shost_class', or we can get everything (hosts, devices,
# etc.) from 'scsi_bus_type'
#
# ...........................................................................
#
# get all Scsi_Host from 'shost_class'
#

def get_scsi_hosts():
    shost_class = readSymbol("shost_class")
    klist_devices = 0

    try:
        klist_devices = shost_class.p.class_devices
    except KeyError:
        pass
    if (not klist_devices):
        try:
            klist_devices = shost_class.p.klist_devices
        except KeyError:
            pass

    out = []
    if (klist_devices):
        for knode in klistAll(klist_devices):
            if (member_size("struct device", "knode_class") != -1):
                dev = container_of(knode, "struct device", "knode_class")
            else:
                devp = container_of(knode, "struct device_private", "knode_class")
                dev = devp.device
            out.append(container_of(dev, "struct Scsi_Host", "shost_dev"))
        return out
    else:
        for hostclass in readSUListFromHead(shost_class.children, "node", "struct class_device"):
            out.append(container_of(hostclass, "struct Scsi_Host", "shost_classdev"))
        return out

scsi_device_types = None
enum_shost_state = None

# Load the modules required for SCSI HBAs
try:
    loadModule("scsi_mod")
    scsi_device_types = readSymbol("scsi_device_types")
    enum_shost_state = EnumInfo("enum scsi_host_state")

    for shost in get_scsi_hosts():
        shost_module = get_hostt_module_name(shost)
        loadModule(shost_module)

except:
    pylog.warning("Error in loading the required debuginfo symbols")
    traceback.print_exc()

# Try loading scsi_transport_fc module
try:
    loadModule("scsi_transport_fc")
except:
    # System is likely not using FiberChannel transport
    pass

# A pathological case on some SLES kernel - something is built
# in a way that even after loading debuginfo we cannot find
# the type of scsi_device_types:
# <data variable, no debug info> scsi_device_types;

def scsi_debuginfo_OK(printwarn=True):
    if (scsi_device_types is None or enum_shost_state is None):
        if (printwarn):
            print("+++Cannot find symbolic info for <scsi_device_types>"
                " or <enum scsi_host_state>\n"
                "   Put 'scsi_mod' debuginfo file into current directory\n"
                "   and then re-run the command adding --reload option")
        return False
    elif (isinstance(scsi_device_types, int)):
        if (printwarn):
            print("+++Debuginfo for this kernel is built in a way\n"
                "  that does not let us analyse SCSI devices, even\n"
                "  after loading debuginfo for SCSI")
        return False
    return True

# The following enums exists on all kernels we support
if (scsi_debuginfo_OK(printwarn=False)):
    enum_st_state = EnumInfo("enum scsi_target_state")

try:
    _rq_atomic_flags = EnumInfo("enum rq_atomic_flags")
except TypeError:
    # RHEL5
    _rq_atomic_flags = {}

if ("REQ_ATOM_COMPLETE" in _rq_atomic_flags):
    _REQ_ATOM_COMPLETE = 1<< _rq_atomic_flags.REQ_ATOM_COMPLETE
else:
    _REQ_ATOM_COMPLETE = None
    
if ("REQ_ATOM_START" in _rq_atomic_flags):
    _REQ_ATOM_START = 1<< _rq_atomic_flags.REQ_ATOM_START
else:
    _REQ_ATOM_START = None

def scsi_device_type(t):
    if (t == 0x1e):
        return "Well-known LUN   "
    elif (t == 0x1f):
        return "No Device        "
    elif (t >= len(scsi_device_types)):
        return "Unknown          "
    return scsi_device_types[t]

if (symbol_exists("fc_rport_dev_release")):
    fc_rport_dev_release = sym2addr("fc_rport_dev_release")
else:
    fc_rport_dev_release = -1
# int scsi_is_fc_rport(const struct device *dev)
#{
#       return dev->release == fc_rport_dev_release;
# }
def scsi_is_fc_rport(dev):
    return (dev.release == fc_rport_dev_release)

#define dev_to_rport(d)                         \
#        container_of(d, struct fc_rport, dev)
def dev_to_rport(d):
    return container_of(d, "struct fc_rport", "dev")

# to_scsi_target(d): (d, struct scsi_target, dev)
def to_scsi_target(d):
    return container_of(d, "struct scsi_target", "dev")

# struct scsi_target *scsi_target(struct scsi_device *sdev) {
# return to_scsi_target(sdev->sdev_gendev.parent);
def scsi_target(sdev):
    return to_scsi_target(sdev.sdev_gendev.parent)

#define starget_to_rport(s)                     \
#        scsi_is_fc_rport(s->dev.parent) ? dev_to_rport(s->dev.parent) : NULL
def starget_to_rport(s):
    parent = s.dev.parent
    return dev_to_rport(parent) if scsi_is_fc_rport(parent) else None


# Generic walk for all devices registered in 'struct class'
def class_for_each_device(_class):
    if (_class.hasField("p")):
        p = _class.p
        if (p.hasField("klist_devices")):
            klist_devices = p.klist_devices
        else:
            klist_devices = p.class_devices

    elif(_class.hasField("klist_devices")):
        klist_devices = _class.klist_devices
    else:
        # RHEL5
        for dev in ListHead(_class.children, "struct class_device").node:
            yield dev
        return

    for knode in klistAll(klist_devices):
        dev = container_of(knode, "struct device", "knode_class")
        yield dev

def scsi_device_lookup(shost):
    for a in ListHead(shost.__devices, "struct scsi_device").siblings:
        yield a

# Get all SCSI devices. There are several ways of doing it, here we 
# loop on shosts and for each shost get its sdevices

@memoize_cond(CU_LIVE|CU_LOAD)
def get_scsi_devices(shost=0):
    out = []

    if (shost):
        out = readSUListFromHead(shost.__devices, "siblings", "struct scsi_device")
    else:
        for host in get_scsi_hosts():
            out += readSUListFromHead(host.__devices, "siblings", "struct scsi_device")

    return out

# Get SCSI command name from scsi_cmnd pointer
def get_cmd_name(cmnd):
    cmd_name = hex(readSU("struct scsi_cmnd", cmnd.cmnd[0]))

    try:
        cmd_name = opcode_table[cmd_name]
    except:
        pass

    return cmd_name

# Get SCSI command age in seconds
def get_cmd_age(cmnd, jiffies = None):
    if (jiffies is None):
        jiffies = readSymbol("jiffies")

    cmd_age = (jiffies - cmnd.jiffies_at_alloc) / HZ

    return cmd_age

# map "struct request" -> ("struct scsi_device", "struct scsi_cmnd")
def req2scsi_info():
    d = {}
    for sdev in get_scsi_devices():
        for cmd in ListHead(sdev.cmd_list, "struct scsi_cmnd").list:
            d[cmd.request] = (sdev, cmd)
    return d


# Decode the scsi_device's sdev_state enum
def get_sdev_state(enum_state):
    if not isinstance(enum_state, long):
        return enum_state
    return {
        1: "SDEV_CREATED",
        2: "SDEV_RUNNING",
        3: "SDEV_CANCEL",
        4: "SDEV_DEL",
        5: "SDEV_QUIESCE",
        6: "SDEV_OFFLINE",
        7: "SDEV_TRANSPORT_OFFLINE",
        8: "SDEV_BLOCK",
        9: "SDEV_CREATED_BLOCK",
    }[enum_state]

# Returns the number of SCSI commands pending on specific Scsi_Host
SCMD_STATE_COMPLETE = 0
SCMD_STATE_INFLIGHT = 1

def test_bit(nbit, val):
    return ((val >> nbit) == 1)

def get_host_busy(shost):
    cmds_in_flight = 0
    cmds = []

    sdevs = get_scsi_devices(shost)
    for sdev in sdevs:
        cmds += get_scsi_commands(sdev)

    for cmd in cmds:
        if (test_bit(SCMD_STATE_INFLIGHT, cmd.state)):
            cmds_in_flight += 1
    return cmds_in_flight

# Check for the scsi_device busy counter
def get_scsi_device_busy(sdev):
    busy = cleared = 0
    sb = sdev.budget_map

    for map_nr in range(sb.map_nr):
        bitmap = sb.map[map_nr].word

        if (not int(bitmap)):
            continue

        depth = 1 << sb.shift
        if map_nr == sb.map_nr - 1:
            depth = sb.depth - depth * map_nr

        for i in range(depth):
            if int(bitmap) & 1:
                busy += 1
            bitmap = bitmap >> 1

    for map_nr in range(sb.map_nr):
        bitmap = sb.map[map_nr].cleared

        if (not int(bitmap)):
            continue

        depth = 1 << sb.shift
        if map_nr == sb.map_nr - 1:
            depth = sb.depth - depth * map_nr

        for i in range(depth):
            if int(bitmap) & 1:
                cleared += 1
            bitmap = bitmap >> 1

    return busy - cleared

# Return the scsi device information in Host(H):Channel(C):Target(T):LunID(L)
# format
def get_scsi_device_id(sdev):
    if (not sdev):
        return "<unknown>"
    return "{:d}:{:d}:{:d}:{:d}".format(sdev.host.host_no,
                                        sdev.channel, sdev.id, sdev.lun)

# Print the most common information from Scsi_Host structure, this includes:
# Host name, (e.g. host1, host2, etc.)
# Driver used by scsi host
# Pointer to Scsi_Host, shost_data and hostdata
def print_shost_header(shost):
    print("HOST      DRIVER")
    print("{:10s}{:22s} {:24s} {:24s} {:24s}".format("NAME", "NAME", "Scsi_Host",
          "shost_data", "hostdata"))
    print("--------------------------------------------------"
          "-------------------------------------------------")
    print("{:9s} {:22s} {:12x} {:24x} {:24x}\n".format(shost.shost_gendev.kobj.name,
        get_hostt_module_name(shost), shost, shost.shost_data, shost.hostdata))

# Retrieve the mapping between request_queue and gendisk struct
def get_gendev():
    gendev_dict = {}
    klist_devices = 0

    if ((member_size("struct device", "knode_class") != -1) or
        (member_size("struct device_private", "knode_class") != -1)):
        block_class = readSymbol("block_class")

        try:
            klist_devices = block_class.p.class_devices
        except KeyError:
            pass

        if (not klist_devices):
            try:
                klist_devices = block_class.p.klist_devices
            except KeyError:
                pass

        if (klist_devices):
            for knode in klistAll(klist_devices):
                if (member_size("struct device", "knode_class") != -1):
                    dev = container_of(knode, "struct device", "knode_class")
                else:
                    devp = container_of(knode, "struct device_private", "knode_class")
                    dev = devp.device
                if struct_exists("struct hd_struct"):
                    hd_temp = container_of(dev, "struct hd_struct", "__dev")
                    gendev = container_of(hd_temp, "struct gendisk", "part0")
                else:
                    blockdev = container_of(dev, "struct block_device", "bd_device")
                    gendev = blockdev.bd_disk
                gendev_q = format(gendev.queue, 'x')
                gendev_dict[gendev_q] = format(gendev, 'x')

    elif (member_size("struct gendisk", "kobj") != -1):
        block_subsys = readSymbol("block_subsys")
        try:
            kset_list = block_subsys.kset.list
        except KeyError:
            pass

        if (kset_list):
            for kobject in readSUListFromHead(kset_list, "entry", "struct kobject"):
                gendev = container_of(kobject, "struct gendisk", "kobj")
                gendev_q = format(gendev.queue, 'x')
                gendev_dict[gendev_q] = format(gendev, 'x')

    else:
        print("Unable to process the vmcore, cant find 'struct class' or 'struct subsystem'.")
        return

    return gendev_dict

# Get the FC/FCoE HBA attributes viz. address of fc_host_attrs struct,
# node_name and port_name
def get_fc_hba_port_attr(shost):
    port_attr = []
    if (struct_exists("struct fc_host_attrs")):
        try:
            fc_host_attrs = readSU("struct fc_host_attrs", shost.shost_data)
            if (fc_host_attrs and ('fc_wq_' in fc_host_attrs.work_q_name[:8])):
                port_attr.append(fc_host_attrs)
                port_attr.append(fc_host_attrs.node_name)
                port_attr.append(fc_host_attrs.port_name)
        except:
            pass

    return port_attr

# Return the elevator or IO scheduler used by the device
def get_sdev_elevator(sdev):
    if (sdev.request_queue.elevator):
        try:
            if (member_size("struct elevator_queue", "elevator_type") != -1):
                elevator_name = sdev.request_queue.elevator.elevator_type.elevator_name
            elif(member_size("struct elevator_queue", "type") != -1):
                elevator_name = sdev.request_queue.elevator.type.elevator_name
            else:
                elevator_name = "<Unknown>"
        except Exception as e:
            elevator_name = "<Unknown>"
            pylog.info("Error getting elevator name for {} {}".format(sdev, e))
    else:
        elevator_name = "<none>"

    return elevator_name

# Get requests from device request_queue
def get_queue_requests(rqueue):
    out = []
    for request in readSUListFromHead(rqueue.queue_head, "queuelist",
                                      "struct request"):
        out.append(request)
    return out

def is_scsi_queue(queue):
    if (member_size("struct request_queue", "mq_ops") == -1 or not queue.mq_ops):
        if (member_size("struct request_queue", "request_fn") != -1):
            if queue.request_fn == sym2addr("scsi_request_fn"):
                return 1
    elif (member_size("struct request_queue", "mq_ops") != -1 and queue.mq_ops == sym2addr("scsi_mq_ops")):
        return 1

    return 0

check_for_sbitmap_word_cleared = 1
all_rq = 0
def find_used_tags(queue, tags, offset, rqs):
    global check_for_sbitmap_word_cleared
    out = []
    if tags.isNamed("struct sbitmap_queue"):
        tags = tags.sb

    dprint("  tag sbitmap {}".format(tags))
    for i in range(tags.map_nr):
        bitmap = tags.map[i].word

        if check_for_sbitmap_word_cleared:
            try:
                mask = ~tags.map[i].cleared
                bitmap = bitmap & mask
            except:
                check_for_sbitmap_word_cleared = 0

        if (not int(bitmap) and not all_rq):
            next

        if (struct_exists("struct blk_mq_bitmap_tags")):
            depth = tags.map[i].depth
        else:
            depth = 1 << tags.shift
            if i == tags.map_nr - 1:
                depth = tags.depth - depth * i
        dprint("    tag depth {}".format(depth))

        for j in range(depth):
            try:
                if int(bitmap) & 1:
                    rq = rqs[offset]
                    if rq and rq.q == queue:
                        if (member_size("struct request", "ref") != -1):
                            try:
                                if rq.ref.refs.counter != 0:
                                    out.append(rq)
                                elif all_rq:
                                    rq._free_ = 1
                                    out.append(rq)
                            except:
                                if rq.ref.counter != 0:
                                    out.append(rq)
                                elif all_rq:
                                    rq._free_ = 1
                                    out.append(rq)
                        else:
                            out.append(rq)
                    elif rq == 0:
                        dprint("  bit set but no request? {} {} map {} rqs {} offset {}".format(queue, tags, i, rqs, offset))
                elif all_rq:
                    rq = rqs[offset]
                    if rq and rq.q == queue:
                        rq._free_ = 1
                        out.append(rq)
            except crash.error:
                print("WARNING: stale address for request {:x} on queue {:x}?".format(rq, queue))

            offset += 1
            bitmap = bitmap >> 1
    return out

# Get the list of SCSI commands
def get_scsi_commands_mq(queue):
    out = []
    cmds = []
    if not queue.mq_ops:
        return out

    #find requests which are tagged and in the various hw queues
    for i in range(queue.nr_hw_queues):
        if (member_size("struct request_queue", "queue_hw_ctx") != -1):
            hctx = queue.queue_hw_ctx[i]
        else:
            hctx = readSU("struct blk_mq_hw_ctx", xarray_entry(queue.hctx_table, i))

        if hctx.tags:
            out += find_used_tags(queue, hctx.tags.breserved_tags,
                                  0, hctx.tags.rqs)
            out += find_used_tags(queue, hctx.tags.bitmap_tags,
                                  hctx.tags.nr_reserved_tags, hctx.tags.rqs)

        if ((member_size("struct blk_mq_hw_ctx", "sched_tags") != -1) and
             hctx.sched_tags):
            out += find_used_tags(queue,
                                  hctx.sched_tags.breserved_tags,
                                  0, hctx.sched_tags.static_rqs)
            out += find_used_tags(queue,
                                  hctx.sched_tags.bitmap_tags,
                                  hctx.sched_tags.nr_reserved_tags,
                                  hctx.sched_tags.static_rqs)

    for rq in out:
        cmd = readSU("struct scsi_cmnd",
            long(Addr(rq) + struct_size("struct request")))
        cmds.append(cmd)

    # I/O scheduler requests can show up in both sched_tags and hw ctx tags,
    # abuse set to remove any duplicates
    cmds = list(set(cmds))

    return cmds

def get_scsi_commands_sq(sdev):
    out = []
    if is_scsi_queue(sdev.request_queue):
        for cmnd in readSUListFromHead(sdev.cmd_list, "list", "struct scsi_cmnd"):
            out.append(cmnd)
    return out

def get_scsi_commands(sdev):
    out = []
    if (member_size("struct request_queue", "mq_ops") == -1):
        out += get_scsi_commands_sq(sdev)
    elif sdev.request_queue.mq_ops:
        out += get_scsi_commands_mq(sdev.request_queue)
    else:
        out += get_scsi_commands_sq(sdev)
    return out

# For v=0 list only different model/vendor combinations, how many a busy
# and different Scsi_Host
# For v=1 we additionally print all scsi devices that are busy/active
# For v=2 we print all scsi devices
def print_SCSI_devices(v=0):
    shosts = set()
    n_busy = 0
    tot_devices = 0
    different_types = set()
    for sdev in get_scsi_devices():
        tot_devices += 1
        shost = sdev.host
        shosts.add(shost)
        busy = atomic_t(sdev.device_busy)
        if (busy):
            n_busy += 1
        _a = []
        _a.append("  Vendor: {:8} Model: {:16} Rev: {:4}".\
            format(sdev.vendor[:8], sdev.model[:16], sdev.rev[:4]))
        _a.append("  Type:   {}                ANSI  SCSI revision: {:02x}".\
            format(scsi_device_type(sdev.type),
                   sdev.scsi_level - (sdev.scsi_level > 1)))
        s_descr = "\n".join(_a)
        different_types.add(s_descr)
        
        # iorequest_cnt-iodone_cnt
        iorequest_cnt = atomic_t(sdev.iorequest_cnt)
        iodone_cnt = atomic_t(sdev.iodone_cnt)
        cntdiff = sdev.iorequest_cnt.counter - sdev.iodone_cnt.counter
        if (v > 1 or (v > 0 and (busy))):
            print('{:-^39}{:-^39}'.format(str(sdev)[8:-1], str(shost)[8:-1]))
            print("Host: scsi{} Channel: {:02} Id: {:02} Lun: {:02}".format(
                shost.host_no, sdev.channel, sdev.id, sdev.lun))
            print(s_descr)

            gendev = sdev.sdev_gendev
            # SD is either 'sysfs_dirent' or 'kernfs_node'
            sd = gendev2sd(gendev)
            print(sysfs_fullpath(sd))
            devname = blockdev_name(sd)
            if (busy == 0):
                sbusy = ''
            else:
                sbusy = " busy={}".format(busy)
            if (devname or busy):
                print("devname={}{}".format(devname, sbusy))
            starget = scsi_target(sdev)
            is_fc = scsi_is_fc_rport(starget.dev.parent)
            st_state = enum_st_state.getnam(starget.state)
            #if (is_fc):
            print("  {} state = {}".format(starget, st_state))
            print("  {}".format(sdev.request_queue))
            
            print("  iorequest_cnt={}, iodone_cnt={}, diff={}".\
                  format(iorequest_cnt, iodone_cnt, cntdiff))
            classified = print_scsi_dev_cmnds(sdev, v)
            if (False and classified != busy):
                print("Mismatch", classified, busy)
            continue
            rport = starget_to_rport(starget)
            print("    ", shost.hostt)
            if (rport):
                print("   ", rport)
            #print(scsi_target(sdev).dev.parent)
    if (different_types):
        print("\n{:=^70}".format(" Summary "))
        print("   -- {} SCSI Devices, {} Are Busy --".\
            format(tot_devices, n_busy))
        print("{:.^70}".format(" Vendors/Types "))
        for _a in different_types:
            print(_a)
            print()
