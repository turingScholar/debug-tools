# --------------------------------------------------------------------
# (C) Copyright 2006-2014 Hewlett-Packard Development Company, L.P.
# (C) Copyright 2014-2015 Red Hat, Inc.
#
# Author: David Jeffery
#
# Contributors:
# - Milan P. Gandhi
#      Added/updated following options:
#       -d     show the scsi devices on system
#              this option is similar to 'shost -d'
#       -s     show Scsi_Host info
#       -T     show scsi targets through which 
#              scsi devices are connected
#       -f     show info on FC rports (a1f34d7bcb06)
#       -q     show info regarging queues (59225677e62b)
#       -v     give verbose info on relevant HBA driver (84a4c55a3f688)
# - John T. Pittman
#      Various fixes and updates due to upstream kernel changes
#
# --------------------------------------------------------------------
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

from __future__ import print_function

__version__ = "0.0.4"

from pykdump.API import *

from LinuxDump.scsi import *

def print_request_header(request, devid):
    print("{:x} {:<13}".format(int(request), "({})".format(devid)), end='')

def display_requests(fields, usehex):
    num_requests = 0
    for sdev in get_scsi_devices():
        cmnd_requests = []
        cmnds = get_scsi_commands(sdev)

        if (member_size("struct request_queue", "queue_head") != -1):
            for cmnd in cmnds:
                cmnd_requests.append(cmnd.request)

            requests = get_queue_requests(sdev.request_queue)
            requests = list(set(requests + cmnd_requests))

            if (requests):
                if (member_size("struct request", "start_time") == -1):
                    if (member_size("struct request", "deadline") != -1):
                        fields = fields.replace("start_time", "deadline")
                    else:
                        fields = fields.replace("start_time", "__deadline")
                if (member_size("struct request", "special") == -1):
                    fields = fields.replace("special", "timeout")
                for req in requests:
                    print_request_header(req, get_scsi_device_id(sdev))
                    display_fields(req, fields, usehex=usehex)
                    num_requests += 1
        else:
            if (cmnds):
                for cmnd in cmnds:
                    print_request_header(cmnd.request, get_scsi_device_id(sdev))
                    if (cmnd.request):
                        display_fields(cmnd.request, "timeout,deadline", usehex=usehex)
                        num_requests += 1
                    else:
                        print("request member of scsi_cmnd {:#x} is null".format(cmnd))

    print("\nRequests found in SCSI layer: {}".format(num_requests))

def print_cmnd_header(cmnd):
    if (cmnd.device):
        print("scsi_cmnd {:x} {:<13}".format(int(cmnd),
              "on scsi_device {:#x} ({})".format(cmnd.device, get_scsi_device_id(cmnd.device))), end='')
    else:
        print("Warning: device member for scsi_cmnd {:x} is null".format(int(cmnd)), end='')

def print_sdev_header(sdev):
    print("{:x}  {:<12}".format(int(sdev),
              get_scsi_device_id(sdev)), end='')

def print_sdev_shost():
    enum_sdev_state = EnumInfo("enum scsi_device_state")

    gendev_dict = get_gendev()

    for shost in get_scsi_hosts():
        if (shost.__devices.next != shost.__devices.next.next):
            print("\n===================================================================="
                  "====================================================================")

            print_shost_header(shost)

            print("{:12s} {:19s} {:12s} {:26s} {:22s} {}  {}    {}".format("DEV NAME",
                  "scsi_device", "H:C:T:L", "VENDOR/MODEL", "DEVICE STATE",
                  "IOREQ-CNT", "IODONE-CNT", "      IOERR-CNT"))
            print("--------------------------------------------------------------------"
                  "--------------------------------------------------------------------")

            for sdev in readSUListFromHead(shost.__devices, "siblings", "struct scsi_device"):
                name = scsi_device_type(sdev.type)

                if (name):
                    if (name in 'Sequential-Access'):
                        name = "Tape"
                    elif (name in 'Medium Changer   '):
                        name = "Chngr"
                    elif (name in 'RAID             '):
                        name = "CTRL"
                    elif ((name in 'Direct-Access    ') or
                          (name in 'CD-ROM           ')):
                         sdev_q = readSU("struct request_queue", sdev.request_queue)
                         sdev_q = format(sdev_q, 'x')
                         try:
                             gendev = gendev_dict[sdev_q]
                             gendev = readSU("struct gendisk", long (gendev, 16))
                             name = gendev.disk_name
                         except:
                             name = "Disk"
                else:
                    name = "null"

                try:
                    sdev_state = get_sdev_state(enum_sdev_state.getnam(sdev.sdev_state))
                except:
                    if (sdev.sdev_state == 9):
                        sdev_state = "SDEV_TRANSPORT_OFFLINE"
                    else:
                        sdev_state = "<Error in processing sdev_state>"
                vendor_str = sdev.vendor[:8].strip() + " " + sdev.model[:16].strip()
                print("{:12s} {:x}    {:12} {:26s} {:20s}"
                      "{:12d} {:11d}  ({:3d}){:12d}".format(name.strip(),
                      sdev, get_scsi_device_id(sdev), vendor_str, sdev_state,
                      sdev.iorequest_cnt.counter, sdev.iodone_cnt.counter,
                      sdev.iorequest_cnt.counter-sdev.iodone_cnt.counter,
                      sdev.ioerr_cnt.counter))

def print_starget_shost():
    enum_starget_state = EnumInfo("enum scsi_target_state")
    stgt_busy_block_cnt = -1

    for shost in get_scsi_hosts():
        if (shost.__targets.next != shost.__targets.next.next):
            print("\n======================================================="
                  "========================================================")

            print_shost_header(shost)

            print("{:15s} {:20s} {:8s} {:6s} {:20s} {:15s} {:15s}".format("TARGET DEVICE",
                  "scsi_target", "CHANNEL", "ID", "TARGET STATUS", 
                  "TARGET_BUSY", "TARGET_BLOCKED"))
            print("----------------------------------------------------"
                  "----------------------------------------------------")

            for starget in readSUListFromHead(shost.__targets, "siblings", "struct scsi_target"):

                if (member_size("struct scsi_target", "target_busy") != -1):
                    try:
                        stgt_busy_block_cnt = readSU("struct scsi_target", long(starget.target_busy.counter))
                    except:
                        stgt_busy_block_cnt = -1

                    try:
                        print("{:15s} {:x} {:3s} {:5d} {:5d} {:4s}"
                              "{:20s}".format(starget.dev.kobj.name,
                              int(starget), "", starget.channel, starget.id, "",
                              enum_starget_state.getnam(starget.state)), end='')

                        if (stgt_busy_block_cnt != -1):
                            print("{:12d} {:18d}".format(starget.target_busy.counter,
                                  starget.target_blocked.counter))

                        elif (stgt_busy_block_cnt == -1 and
                              member_size("struct scsi_target", "target_busy") == -1):
                            print(" <Not defined in scsi_target>")

                        else:
                            print("{:12d} {:18d}".format(starget.target_busy,
                                  starget.target_blocked))

                    except KeyError:
                        pylog.warning("Error in processing scsi_target {:x},"
                                      "please check manually".format(int(starget)))

def print_fcrports():
    supported_modules = ["lpfc", "qla2xxx", "fnic", "qedf", "bfa", "zfcp"]
    for shost in get_scsi_hosts():
        if (shost.__targets.next != shost.__targets.next.next and
            get_hostt_module_name(shost) in supported_modules):
            print("\n==================================================="
                  "====================================================="
                  "==================================================")

            print_shost_header(shost)

            print("{:15s} {:16s} {:16s} {:16s} {:16s} {:11s} {:24s} {:20s} {:16s}".format("TARGET DEVICE",
                  "scsi_target", "fc_rport", "node_name", "port_name", "port_id",
                  "port_state", "fast_io_fail_tmo", "dev_loss_tmo"))
            print("----------------------------------------------------"
                  "----------------------------------------------------"
                  "--------------------------------------------------")

            enum_fcrport_state = EnumInfo("enum fc_port_state")

            for starget in readSUListFromHead(shost.__targets, "siblings", "struct scsi_target"):
                try:
                    fc_rport = starget_to_rport(starget)
                    print("{:15s} {:x} {:x} {:x} {:x} {:#x}\t{:24s}{:16d}s {:15d}s".format(starget.dev.kobj.name,
                          starget, fc_rport, fc_rport.node_name, fc_rport.port_name, fc_rport.port_id,
                          enum_fcrport_state.getnam(fc_rport.port_state), fc_rport.fast_io_fail_tmo,
                          fc_rport. dev_loss_tmo))
                except KeyError:
                    pylog.warning("Error in processing FC rports connnected to scsi_target {:x},"
                                  "please check manually".format(int(starget)))

def print_qla2xxx_shost_info(shost):
    print("\n\n   FC/FCoE HBA attributes")
    print("   ----------------------")

    port_attr = get_fc_hba_port_attr(shost)

    if (len(port_attr)):
        print("   fc_host_attrs       : {:x}".format(port_attr[0]))
        print("   node_name (wwnn)    : {:x}".format(port_attr[1]))
        print("   port_name (wwpn)    : {:x}".format(port_attr[2]))
    else:
        print("   Error in fetching port wwnn and wwpn")

    print("\n\n   QLogic HBA specific details")
    print("   ---------------------------")

    if (struct_exists("struct qla_hw_data")):
        scsi_qla_host = readSU("struct scsi_qla_host", shost.hostdata)
        qla_hw_data = readSU("struct qla_hw_data", scsi_qla_host.hw)
        print("   scsi_qla_host       : {:x}".format(scsi_qla_host))
        print("   qla_hw_data         : {:x}".format(qla_hw_data))
        print("   pci_dev             : {:x}".format(qla_hw_data.pdev))
        print("   pci_dev slot        : {}".format(qla_hw_data.pdev.dev.kobj.name))
        print("   operating_mode      : {}".format(qla_hw_data.operating_mode))
        print("   model_desc          : {}".format(qla_hw_data.model_desc))
        print("   optrom_state        : {}".format(qla_hw_data.optrom_state))
        print("   fw_major_version    : {}".format(qla_hw_data.fw_major_version))
        print("   fw_minor_version    : {}".format(qla_hw_data.fw_minor_version))
        print("   fw_subminor_version : {}".format(qla_hw_data.fw_subminor_version))
        print("   fw_dumped           : {}".format(qla_hw_data.fw_dumped))
        print("   ql2xmaxqdepth       : {}".format(readSymbol("ql2xmaxqdepth")))
    else:
        print("   Error in fetching verbose details from struct qla_hw_data")

def print_bfa_shost_info(shost):
    print("\n\n   FC/FCoE HBA attributes")
    print("   ----------------------")

    port_attr = get_fc_hba_port_attr(shost)

    if (len(port_attr)):
        print("   fc_host_attrs       : {:x}".format(port_attr[0]))
        print("   node_name (wwnn)    : {:x}".format(port_attr[1]))
        print("   port_name (wwpn)    : {:x}".format(port_attr[2]))
    else:
        print("   Error in fetching port wwnn and wwpn")

    print("\n\n   Brocade HBA specific details")
    print("   ---------------------------")

    if (struct_exists("struct bfad_im_port_s")):
        im_port = readPtr(shost.hostdata)
        bfad_im_port_s =  readSU("struct bfad_im_port_s", im_port)
        bfad_s = readSU("struct bfad_s", bfad_im_port_s.bfad)
        pcidev = readSU("struct pci_dev", bfad_s.pcidev)
        print("   bfad_im_port_s      : {:x}".format(bfad_im_port_s))
        print("   bfad_s              : {:x}".format(bfad_s))
        print("   pci_dev             : {:x}".format(pcidev))
        print("   pci_dev slot        : {}".format(pcidev.dev.kobj.name))
    else:
        print("Error in fetching verbose details for BFA module")

def print_lpfc_shost_info(shost):
    print("\n\n   FC/FCoE HBA attributes")
    print("   ----------------------")

    port_attr = get_fc_hba_port_attr(shost)

    if (len(port_attr)):
        print("   fc_host_attrs       : {:x}".format(port_attr[0]))
        print("   node_name (wwnn)    : {:x}".format(port_attr[1]))
        print("   port_name (wwpn)    : {:x}".format(port_attr[2]))
    else:
        print("   Error in fetching port wwnn and wwpn")

    print("\n\n   Emulex HBA specific details")
    print("   ---------------------------")

    if (struct_exists("struct lpfc_hba")):
        lpfc_vport = readSU("struct lpfc_vport", shost.hostdata)
        lpfc_hba = readSU("struct lpfc_hba", lpfc_vport.phba)
        print("   lpfc_vport          : {:x}".format(lpfc_vport))
        print("   lpfc_hba            : {:x}".format(lpfc_hba))
        print("   sli_rev             : {}".format(lpfc_hba.sli_rev))
        print("   pci_dev             : {:x}".format(lpfc_hba.pcidev))
        print("   pci_dev slot        : {}".format(lpfc_hba.pcidev.dev.kobj.name))
        print("   brd_no              : {}".format(lpfc_hba.brd_no))
        print("   SerialNumber        : {}".format(lpfc_hba.SerialNumber))
        print("   OptionROMVersion    : {}".format(lpfc_hba.OptionROMVersion))
        print("   ModelDesc           : {}".format(lpfc_hba.ModelDesc))
        print("   ModelName           : {}".format(lpfc_hba.ModelName))
        print("   cfg_hba_queue_depth : {}".format(lpfc_hba.cfg_hba_queue_depth))
        print("   cfg_lun_queue_depth : {}".format(lpfc_vport.cfg_lun_queue_depth))
        if (member_size("struct lpfc_vport", "cfg_tgt_queue_depth") != -1):
            print("   cfg_tgt_queue_depth : {}".format(lpfc_vport.cfg_tgt_queue_depth))
    else:
        print("   Error in fetching verbose details from struct lpfc_hba")

def print_hpsa_shost_info(shost):
    print("\n\n   HPSA HBA specific details")
    print("   ---------------------------")

    if (struct_exists("struct ctlr_info")):
        ctlr_info = readSU("struct ctlr_info", shost.hostdata[0])
        print("   ctlr_info           : {:x}".format(ctlr_info))
        print("   pci_dev             : {:x}".format(ctlr_info.pdev))
        print("   pci_dev slot        : {}".format(ctlr_info.pdev.dev.kobj.name))
        print("   devname             : {}".format(ctlr_info.devname))
        print("   product_name        : {}".format(ctlr_info.product_name))
        print("   board_id            : {:#x}".format(ctlr_info.board_id))
        print("   fwrev               : {:c}{:c}{:c}{:c}{:c}".format(ctlr_info.hba_inquiry_data[32],
            ctlr_info.hba_inquiry_data[33], ctlr_info.hba_inquiry_data[34],
            ctlr_info.hba_inquiry_data[35], ctlr_info.hba_inquiry_data[36]))
        print("   CommandList         : {:x}".format(ctlr_info.cmd_pool))
        print("   nr_cmds             : {}".format(ctlr_info.nr_cmds))
        print("   max_commands        : {}".format(ctlr_info.max_commands))
        print("   commands_outstanding: {}".format(ctlr_info.commands_outstanding.counter))
        print("   interrupts_enabled  : {}".format(ctlr_info.interrupts_enabled))
        print("   intr_mode           : {}".format(ctlr_info.intr_mode))
        print("   remove_in_progress  : {}".format(ctlr_info.remove_in_progress))
        print("   reset_in_progress   : {}".format(ctlr_info.reset_in_progress))
    else:
        print("   Error in fetching verbose details from struct ctlr_info")

def print_vmw_pvscsi_shost_info(shost):
    print("\n\n   PVSCSI HBA specific details")
    print("   ---------------------------")

    if (struct_exists("struct pvscsi_adapter")):
        pvscsi_adapter = readSU("struct pvscsi_adapter", shost.hostdata)
        pci_dev = readSU("struct pci_dev", pvscsi_adapter.dev)
        print("   pvscsi_adapter      : {:x}".format(pvscsi_adapter))
        print("   pci_dev             : {:x}".format(pci_dev))
        print("   pci_dev slot        : {}".format(pci_dev.dev.kobj.name))
        print("   req_pages           : {}".format(pvscsi_adapter.req_pages))
        print("   req_depth           : {}".format(pvscsi_adapter.req_depth))
        if (member_size("struct pvscsi_adapter", "use_req_threshold") != -1):
            print("   use_req_threshold   : {}".format(pvscsi_adapter.use_req_threshold))
        print("   PVSCSIRingReqDesc   : {:x}".format(pvscsi_adapter.req_ring))
        print("   PVSCSIRingCmpDesc   : {:x}".format(pvscsi_adapter.cmp_ring))
        print("   PVSCSIRingMsgDesc   : {:x}".format(pvscsi_adapter.msg_ring))
        print("   PVSCSIRingsState    : {:x}".format(pvscsi_adapter.rings_state))
        print("   cmd_pool            : {:x}".format(pvscsi_adapter.cmd_pool))
    else:
        print("   Error in fetching verbose details from struct pvscsi_adapter")

def print_qedf_shost_info(shost):
    print("\n\n   FC/FCoE HBA attributes")
    print("   ----------------------")

    port_attr = get_fc_hba_port_attr(shost)

    if (len(port_attr)):
        print("   fc_host_attrs       : {:x}".format(port_attr[0]))
        print("   node_name (wwnn)    : {:x}".format(port_attr[1]))
        print("   port_name (wwpn)    : {:x}".format(port_attr[2]))
    else:
        print("   Error in fetching port wwnn and wwpn")

    print("\n\n   QLogic FastLinQ HBA specific details")
    print("   ------------------------------------")

    if (struct_exists("struct qedf_ctx")):
        qedf_ctx = readSU("struct qedf_ctx", shost.hostdata + struct_size("struct fc_lport"))
        print("   qedf_ctx            : {:x}".format(qedf_ctx))
        print("   fc_lport            : {:x}".format(qedf_ctx.lport))
        print("   fcoe_ctlr           : {:x}".format(qedf_ctx.ctlr))
        print("   vlan_id             : {:#x}".format(qedf_ctx.vlan_id))
        print("   qed_dev             : {:x}".format(qedf_ctx.cdev))
        print("   firmware major      : {:d}".format(qedf_ctx.cdev.fw_data.fw_ver_info.num.major))
        print("   firmware minor      : {:d}".format(qedf_ctx.cdev.fw_data.fw_ver_info.num.minor))
        print("   firmware rev        : {:d}".format(qedf_ctx.cdev.fw_data.fw_ver_info.num.rev))
        print("   firmware eng        : {:d}".format(qedf_ctx.cdev.fw_data.fw_ver_info.num.eng))
        print("   pci_dev             : {:x}".format(qedf_ctx.pdev))
        print("   pci_dev slot        : {}".format(qedf_ctx.pdev.dev.kobj.name))
        print("   curr_conn_id        : {}".format(qedf_ctx.curr_conn_id))
        print("   qedf_fastpath       : {:x}".format(qedf_ctx.fp_array))
        print("   qedf_cmd_mgr        : {:x}".format(qedf_ctx.cmd_mgr))
        print("   stop_io_on_error    : {}".format(qedf_ctx.stop_io_on_error))
        print("   flogi_cnt           : {}".format(qedf_ctx.flogi_cnt))
        print("   flogi_failed        : {}".format(qedf_ctx.flogi_failed))
        print("   flogi_pending       : {}".format(qedf_ctx.flogi_pending))
        print("   input_requests      : {}".format(qedf_ctx.input_requests))
        print("   output_requests     : {}".format(qedf_ctx.output_requests))
        print("   control_requests    : {}".format(qedf_ctx.control_requests))
        print("   packet_aborts       : {}".format(qedf_ctx.packet_aborts))
        print("   alloc_failures      : {}".format(qedf_ctx.alloc_failures))
        print("   lun_resets          : {}".format(qedf_ctx.lun_resets))
        print("   target_resets       : {}".format(qedf_ctx.target_resets))
        print("   task_set_fulls      : {}".format(qedf_ctx.task_set_fulls))
        print("   busy                : {}".format(qedf_ctx.busy))
    else:
        print("   Error in fetching verbose details from struct qedf_ctx")

def print_fnic_shost_info(shost):
    print("\n\n   FC/FCoE HBA attributes")
    print("   ----------------------")

    port_attr = get_fc_hba_port_attr(shost)

    if (len(port_attr)):
        print("   fc_host_attrs       : {:x}".format(port_attr[0]))
        print("   node_name (wwnn)    : {:x}".format(port_attr[1]))
        print("   port_name (wwpn)    : {:x}".format(port_attr[2]))
    else:
        print("   Error in fetching port wwnn and wwpn")

    print("\n\n   Cisco FCoE HBA specific details")
    print("   -------------------------------")

    if (struct_exists("struct fnic")):
        fnic = readSU("struct fnic", shost.hostdata + struct_size("struct fc_lport"))
        print("   fnic                : {:x}".format(fnic))
        print("   fc_lport            : {:x}".format(fnic.lport))
        print("   fcoe_ctlr           : {:x}".format(fnic.ctlr))
        print("   pci_dev             : {:x}".format(fnic.pdev))
        print("   pci_dev slot        : {}".format(fnic.pdev.dev.kobj.name))
        print("   fnic_stats          : {:x}".format(fnic.fnic_stats))
        print("   in_flight           : {}".format(atomic_t(fnic.in_flight)))
        print("   reset_inprogress    : {}".format(fnic.internal_reset_inprogress))
        print("   vlan_id             : {:x}".format(fnic.vlan_id))
        print("   link_down_cnt       : {}".format(fnic.link_down_cnt))
    else:
        print("   Error in fetching verbose details from struct fnic")

def print_zfcp_shost_info(shost):
    print("\n\n   FC HBA attributes")
    print("   -----------------")

    port_attr = get_fc_hba_port_attr(shost)

    if (len(port_attr)):
        print("   fc_host_attrs       : {:x}".format(port_attr[0]))
        print("   node_name (wwnn)    : {:x}".format(port_attr[1]))
        print("   port_name (wwpn)    : {:x}".format(port_attr[2]))
    else:
        print("   Error in fetching port wwnn and wwpn")

    print("\n\n   zfcp specific details")
    print("   ---------------------")

    if (struct_exists("struct zfcp_adapter")):
        a = readSU("struct zfcp_adapter", shost.hostdata[0])
        print("   zfcp_adapter        : {:x}".format(a))
        print("   ccw dev bus ID      : {}".format(a.ccw_device.dev.kobj.name))
    else:
        print("   Error in fetching verbose details from struct zfcp_adapter")

def print_shost_info():
    enum_shost_state = EnumInfo("enum scsi_host_state")

    hosts = get_scsi_hosts()
    mod_with_verbose_info = ["lpfc", "qla2xxx", "fnic", "hpsa", "vmw_pvscsi", "qedf", "bfa", "zfcp"]
    verbose_info_logged = 0
    verbose_info_available = 0

    for shost in hosts:
        print("\n============================================================="
              "============================================================")

        print_shost_header(shost)

        try:
            print("   Driver version      : {}".format(shost.hostt.module.version))
            print("   Taints bitmask      : {:#x}".format(shost.hostt.module.taints))
            if (shost.hostt.module.taints):
                print("   WARNING: Out-of-box or tech-preview SCSI host module ({}) loaded. "
                      "Output from scsishow may be impacted.".format(get_hostt_module_name(shost)))
        except:
            pylog.warning("Error in processing Scsi_Host->hostt->module details")

        if (member_size("struct Scsi_Host", "host_busy") != -1):
            print("\n   host_busy           : {}".format(atomic_t(shost.host_busy)), end="")
        else:
            print("\n   host_busy           : {}".format(get_host_busy(shost)), end="")
        print("\n   host_blocked        : {}".format(atomic_t(shost.host_blocked)))

        print("   host_failed         : {}".format(shost.host_failed))
        print("   host_self_blocked   : {}".format(shost.host_self_blocked))
        print("   shost_state         : {}".format(enum_shost_state.getnam(shost.shost_state)))

        if (member_size("struct Scsi_Host", "eh_deadline") != -1):
            if (shost.eh_deadline == -1 and shost.hostt.eh_host_reset_handler != 0):
                print("   eh_deadline         : {} (off)".format(shost.eh_deadline))
            elif (shost.eh_deadline == -1 and shost.hostt.eh_host_reset_handler == 0):
                print("   eh_deadline         : {} (off, not supported by driver)".format(
                      shost.eh_deadline))
            elif (shost.eh_deadline != -1 and shost.hostt.eh_host_reset_handler != 0):
                print("   eh_deadline         : {}".format(shost.eh_deadline))

        print("   max_lun             : {}".format(shost.max_lun))
        print("   cmd_per_lun         : {}".format(shost.cmd_per_lun))
        print("   work_q_name         : {}".format(shost.work_q_name))

        if (verbose):
            try:
                if (('lpfc' in get_hostt_module_name(shost))):
                    print_lpfc_shost_info(shost)

                elif (('qla2xxx' in get_hostt_module_name(shost))):
                    print_qla2xxx_shost_info(shost)

                elif (('hpsa' in get_hostt_module_name(shost))):
                    print_hpsa_shost_info(shost)

                elif (('vmw_pvscsi' in get_hostt_module_name(shost))):
                    print_vmw_pvscsi_shost_info(shost)

                elif (('qedf' in get_hostt_module_name(shost))):
                    print_qedf_shost_info(shost)

                elif (('fnic' in get_hostt_module_name(shost))):
                    print_fnic_shost_info(shost)

                elif (('bfa' in get_hostt_module_name(shost))):
                    print_bfa_shost_info(shost)

                elif (('zfcp' in get_hostt_module_name(shost))):
                    print_zfcp_shost_info(shost)

                verbose_info_logged += 1
            except:
                pylog.warning("Error in processing verbose details for Scsi_Host: "
                              "{} ({:x})".format(shost.shost_gendev.kobj.name, shost))

        if (get_hostt_module_name(shost) in mod_with_verbose_info):
            verbose_info_available += 1

    if (verbose_info_available != 0 and verbose_info_logged == 0):
        print("\n\n   *** NOTE: More detailed HBA information available, use '-v'"
              " or '--verbose' to view.")

def print_queue(sdev):
    cmnd_requests = []
    cmnds = get_scsi_commands(sdev)
    for cmnd in cmnds:
        cmnd_requests.append(cmnd.request)

    if (member_size("struct request_queue", "queue_head") != -1):
        requests = get_queue_requests(sdev.request_queue)
        requests = list(set(requests + cmnd_requests))
    else:
        requests = cmnd_requests

    print("\n     {:10s}{:20s} {:20s} {:18s} {:14s} {:20s} {:10s}".format("NO.", "request",
          "bio", "scsi_cmnd", "OPCODE", "COMMAND AGE", "SECTOR"))
    print("     ---------------------------------------------------------"
          "--------------------------------------------------------")

    counter = 0
    for req in requests:
        counter = counter + 1
        try:
            if ((member_size("struct request_queue", "mq_ops") != -1) and req.q.mq_ops):
                cmnd = readSU("struct scsi_cmnd",
                    long(Addr(req) + struct_size("struct request")))
            else:
                cmnd = readSU("struct scsi_cmnd", long(req.special))
        except:
            cmnd = 0

        if (cmnd):
            cmd_age = get_cmd_age(cmnd)
            cmd_name = get_cmd_name(cmnd)
            print("     {:3d} {:3s} {:18x} {:20x} {:20x}   {:14} {:10.3f}s ".format(counter, "",
                  req, req.bio, cmnd, cmd_name, cmd_age), end="")
        else:
            print("     {:3d} {:3s} {:18x} {:20x} {:20x}   {:14} {:12}".format(counter, "",
                  req, req.bio, cmnd, "-NA-", "-NA-"), end="")

        if (req.bio):
            if (member_size("struct bio", "bi_sector") != -1):
                print("{:15d}".format(req.bio.bi_sector))
            else:
                print("{:15d}".format(req.bio.bi_iter.bi_sector))
        else:
                print("       ---NA---")
    if (counter == 0):
        print("\t\t<<< NO I/O REQUESTS FOUND ON THE DEVICE! >>>")

def print_request_queue():
    gendev_dict = get_gendev()

    for sdev in get_scsi_devices():
        gendev_present = 1
        elevator_name = get_sdev_elevator(sdev)
        vendor_str = sdev.vendor[:8].strip() + " " + sdev.model[:16].strip()
        sdev_q = readSU("struct request_queue", sdev.request_queue)
        sdev_q = format(sdev_q, 'x')
        try:
            gendev = gendev_dict[sdev_q]
            gendev = readSU("struct gendisk", long (gendev, 16))
            name = gendev.disk_name
        except:
            gendev_present = 0
            name = scsi_device_type(sdev.type)
            if (not name):
                name = "null"
            elif (name in 'Sequential-Access'):
                name = "Tape"
            elif (name in 'Medium Changer   '):
                name = "Chngr"
            elif (name in 'RAID             '):
                name = "CTRL"

        print("\n==========================================================="
              "============================================================")
        print("    ### DEVICE : {}\n".format(name))

        print("        ----------------------------------------------------"
              "-----------------------------------")

        if (not (gendev_present)):
            print("\tgendisk        \t:  {} |"
                  "\tscsi_device \t:  {:x}".format("<Can't find gendisk>", int(sdev)))
        else:
            print("\tgendisk        \t:  {:x}\t|\tscsi_device \t:  {:x}".format(int(gendev), int(sdev)))
        print("\trequest_queue  \t:  {}\t|\tH:C:T:L       \t:  {}".format(sdev_q,
              sdev.sdev_gendev.kobj.name))
        print("\televator_name  \t:  {}    \t\t|\tVENDOR/MODEL\t:  {}".format(elevator_name,
              vendor_str))
        print("        ----------------------------------------------------"
              "-----------------------------------")

        print_queue(sdev)

def lookup_field(obj, fieldname):
    segments = fieldname.split("[")
    while (len(segments) > 0):
        obj = obj.Eval(segments[0])
        if (len(segments) > 1):
            offset = segments[1].split("]")
            if (isinstance(obj, SmartString)):
                obj = obj[long(offset[0])]
            else:
                obj = obj.__getitem__(long(offset[0]))

            if ((len(offset) > 1) and offset[1]):
                # We've consumed one segment, toss it and replace the next
                # segment with a string witout the "]."
                segments = segments[1:]
                #FIXME: we need to drop a leading ".", but should check first
                segments[0] = offset[1][1:]
            else:
                return obj
        else:
            return obj
    return obj


def display_fields(display, fieldstr, evaldict={}, usehex=0, relative=0):
    evaldict['display'] = display
    for fieldname in fieldstr.split(","):
        try:
            field = lookup_field(display, fieldname)
#        field = eval("display.{}".format(fieldname),{}, evaldict)
            if (relative):
                try:
                    field = long(field) - long(relative)
                except ValueError:
                    field = long(field) - long(readSymbol(relative))
        except (IndexError, crash.error) as e:
            field = "\"ERROR {}\"".format(e)

        if (usehex or isinstance(field, StructResult) or
                      isinstance(field, tPtr)):
            try:
                print(" {}: {:<#10x}".format(fieldname, field), end='')
            except ValueError:
                print(" {}: {:<10}".format(fieldname, field), end='')
        else:
            print(" {}: {:<10}".format(fieldname, field), end='')
    del evaldict['display']
    print("")

#x86_64 only!
def is_kernel_address(addr):
    if ((addr & 0xffff000000000000) != 0xffff000000000000):
        return 0
    if (addr > -65536):
        return 0
    if ((addr & 0xfffff00000000000) == 0xffff800000000000):
        return 1
    if ((addr & 0xffffff0000000000) == 0xffffea0000000000):
        return 1
    if ((addr & 0xffffffff00000000) == 0xffffffff00000000):
        return 1
    return 0

def display_command_time(cmnd, use_start_time_ns):
    rq_start_time = 0
    start_time = 0
    deadline = 0
    jiffies = readSymbol("jiffies")
    state = "unknown"
    HZ = sys_info.HZ

    # get time scsi_cmnd allocated/started
    try:
        start_time = cmnd.jiffies_at_alloc
    except KeyError:
        pass

    if (start_time):
        start_time -= jiffies
    else:
        start_time = "Err"

    try:
        if use_start_time_ns:
            rq_start_time = cmnd.request.start_time_ns
        else:
            rq_start_time = cmnd.request.start_time

    except KeyError:
        pass

    # get time request allocated/started
    if (rq_start_time):
        if use_start_time_ns:
            jiffies_ns = (jiffies - ((-300 * HZ) & 0xffffffff)) * 1000000000 / HZ
            rq_start_time = int((rq_start_time - jiffies_ns) * HZ / 1000000000)
        else:
            rq_start_time -= jiffies
    else:
        rq_start_time = "Err"

    try:
        if (member_size("struct request", "deadline") != -1):
            deadline = cmnd.request.deadline
        else:
            deadline = cmnd.request.__deadline

        if (long(cmnd.request.timeout_list.next)
               != long(cmnd.request.timeout_list)):
            state = "active"
        elif (cmnd.eh_entry.next and
              (long(cmnd.eh_entry.next) != long(cmnd.eh_entry))):
            state = "timeout"
        #csd.list next/prev pointers  may be uninitiallized, so check for sanity
        elif (cmnd.request.csd.list.next and cmnd.request.csd.list.prev and
              (long(cmnd.request.csd.list.next) != long(cmnd.request.csd.list))
              and is_kernel_address(long(cmnd.request.csd.list.next)) and
              is_kernel_address(long(cmnd.request.csd.list.prev))):
            state = "softirq"
        elif (long(cmnd.request.queuelist) != long(cmnd.request.queuelist.next)):
            state = "queued"

    except KeyError:
        pass

    try:
        deadline = cmnd.eh_timeout.expires
        if (cmnd.eh_timeout.entry.next):
            state = "active"
        elif (cmnd.eh_entry.next and
              (long(cmnd.eh_entry.next) != long(cmnd.eh_entry))):
            state = "timeout"
        elif (long(cmnd.request.queuelist) != long(cmnd.request.queuelist.next)):
            state = "queued"
        elif (long(cmnd.request.donelist) != long(cmnd.request.donelist.next)):
            state = "softirq"
    except KeyError:
        pass

    # get time to timeout or state
    if (deadline):
        deadline -= jiffies
    else:
        deadline = "N/A"

    print(" is {}, deadline: {} cmnd-alloc: {} rq-alloc: {}".format(state, deadline, start_time, rq_start_time), end='')

def run_host_checks():
    host_warnings = 0

    for host in get_scsi_hosts():
        if (host.host_failed):
            host_warnings += 1

            if (member_size("struct Scsi_Host", "host_busy") != -1):
                host_busy = atomic_t(host.host_busy)
            else:
                host_busy = get_host_busy(host)

            if (host.host_failed == host_busy):
                print("WARNING: Scsi_Host {:#x} ({}) is running error recovery!".format(host,
                      host.shost_gendev.kobj.name))
            else:
                print("WARNING: Scsi_Host {:#x} ({}) has timed out commands, but has not started "
                      "error recovery!".format(host, host.shost_gendev.kobj.name))

            if (atomic_t(host.host_blocked)):
                host_warnings += 1
                print("WARNING: Scsi_Host {:#x} ({}) is blocked! HBA driver refusing all commands with SCSI_MLQUEUE_HOST_BUSY?".format(host,
                    host.shost_gendev.kobj.name))
    return host_warnings

def run_cmd_checks(sdev):
    cmd_warnings = 0
    jiffies = readSymbol("jiffies")

    for cmnd in get_scsi_commands(sdev):
        timeout = 0
        if (cmnd.request):
            try:
                timeout = cmnd.request.timeout
            except KeyError:
                timeout = -1
        else:
            print("WARNING: cmnd.request is null for scsi_cmnd {:#x}".format(cmnd))

        if (timeout == -1):
            try:
                timeout = cmnd.timeout_per_command
            except KeyError:
                print("Error: cannot determine timeout!")
                timeout = 0

        # Check for large timeout values
        if (timeout >= 300000):
            cmd_warnings += 1
            print("WARNING: scsi_cmnd {:#x} on scsi_device {:#x} ({}) has a huge timeout of {}ms!".format(cmnd,
                   cmnd.device, get_scsi_device_id(cmnd.device), timeout))
        elif (timeout > 60000):
            cmd_warnings += 1
            print("WARNING: scsi_cmnd {:#x} on scsi_device {:#x} ({}) has a large timeout of {}ms.".format(cmnd,
                   cmnd.device, get_scsi_device_id(cmnd.device), timeout))

        # check for old command
        if (timeout and jiffies > (timeout + cmnd.jiffies_at_alloc)):
            cmd_warnings += 1
            print("WARNING: scsi_cmnd {:#x} on scsi_device {:#x} ({}) older than its timeout: "
                  "EH or stalled queue?".format(cmnd, cmnd.device, get_scsi_device_id(cmnd.device)))

        # check for commands that have been retried, indicating potential prior failure
        if (cmnd.retries > 0):
            cmd_warnings += 1
            print("WARNING: scsi_cmnd {:#x} on scsi_device {:#x} ({}) has a retries value of {}!".format(cmnd,
                   cmnd.device, get_scsi_device_id(cmnd.device), cmnd.retries))

        # check for non-zero result values
        if (cmnd.result > 0):

            if len(hex(cmnd.result)) > 10:
                print("WARNING: scsi_cmnd {:#x} on scsi_device {:#x} ({}) has a result value of {}!".format(cmnd,
                    cmnd.device, get_scsi_device_id(cmnd.device), hex(cmnd.result)))
                cmd_warnings += 1
                break

            status_byte = (((cmnd.result) >> 0) & 0xff)
            if status_byte in scmd_status_byte:
                status_byte = scmd_status_byte[status_byte]
            else:
                status_byte = "invalid value: " + hex(status_byte)

            msg_byte = (((cmnd.result) >> 8) & 0xff)
            if msg_byte in scmd_msg_byte:
                msg_byte = scmd_msg_byte[msg_byte]
            else:
                msg_byte = "invalid value: " + hex(host_byte)

            host_byte = (((cmnd.result) >> 16) & 0xff)
            if host_byte in scmd_host_byte:
                host_byte = scmd_host_byte[host_byte]
            else:
                host_byte = "invalid value: " + hex(host_byte)

            driver_byte = (((cmnd.result) >> 24) & 0xff)
            if driver_byte in scmd_driver_byte:
                driver_byte = scmd_driver_byte[driver_byte]
            else:
                driver_byte = "invalid value: " + hex(driver_byte)

            print("WARNING: scsi_cmnd {:#x} on scsi_device {:#x} ({}) has a result value of {}! driver_byte: {} host_byte: {} "
                "msg_byte: {} status_byte: {}".format(cmnd, cmnd.device, get_scsi_device_id(cmnd.device), hex(cmnd.result),
                driver_byte, host_byte, msg_byte, status_byte))
            cmd_warnings += 1

        # check for incorrect mapped buffer count
        if (cmnd.device):
            if (cmnd.sdb.table.nents > cmnd.device.host.sg_tablesize):
                print("ERROR:   scsi_cmnd {:#x} on scsi_device {:#x} ({}) has cmnd.sdb.table.nents count ({}) "
                      "more than Scsi_Host->sg_tablesize ({})".format(cmnd, cmnd.device,
                      get_scsi_device_id(cmnd.device), cmnd.sdb.table.nents, cmnd.device.host.sg_tablesize))
                cmd_warnings += 1
        if (cmnd.request):
            if (cmnd.sdb.table.nents > cmnd.request.q.limits.max_segments):
                print("ERROR:   scsi_cmnd {:#x} on scsi_device {:#x} ({}) has cmnd.sdb.table.nents count ({}) "
                      "more than request_queue.limits.max_segments ({})".format(cmnd, cmnd.device,
                      get_scsi_device_id(cmnd.device), cmnd.sdb.table.nents, cmnd.request.q.limits.max_segments))
                cmd_warnings += 1

    return cmd_warnings

def run_sdev_cmd_checks():
    dev_warnings = 0
    cmd_warnings = 0
    retry_delay_bug = 0
    qla_cmd_abort_bug = 0
    gendev_q_sdev_q_mismatch = 0
    jiffies = readSymbol("jiffies")

    enum_sdev_state = EnumInfo("enum scsi_device_state")

    gendev_dict = get_gendev()

    for sdev in get_scsi_devices():
        if (atomic_t(sdev.device_blocked)):
            dev_warnings += 1
            print("WARNING: scsi_device {:#x} ({}) is blocked! HBA driver returning "
                    "SCSI_MLQUEUE_DEVICE_BUSY or device returning SAM_STAT_BUSY?".format(sdev,
                    get_scsi_device_id(sdev)))

        try:
            sdev_state = get_sdev_state(enum_sdev_state.getnam(sdev.sdev_state))
        except:
            if (sdev.sdev_state == 9):
                sdev_state = "SDEV_TRANSPORT_OFFLINE"
            else:
                sdev_state = "<Unknown>"

        if (sdev.sdev_state != 2):
            dev_warnings += 1
            print("WARNING: scsi_device {:#x} ({}) is in {} state".format(sdev,
                    get_scsi_device_id(sdev), sdev_state))

        if (member_size("struct scsi_device", "device_busy") != -1):
            device_busy = atomic_t(sdev.device_busy)
        else:
            device_busy = get_scsi_device_busy(sdev)

        if (device_busy < 0):
            dev_warnings += 1
            print("ERROR:   scsi_device {:#x} ({}) device_busy count is: {}".format(sdev,
                get_scsi_device_id(sdev), device_busy))
            if (sdev.host.hostt.name in "qla2xxx"):
                qla_cmd_abort_bug += 1

        # Check if scsi_device->request_queue is same as corresponding gendisk->queue.
        name = scsi_device_type(sdev.type)
        if (name):
            if (name in 'Direct-Access    '):
                sdev_q = readSU("struct request_queue", sdev.request_queue)
                sdev_q = format(sdev_q, 'x')
                try:
                    gendev = gendev_dict[sdev_q]
                except:
                    gendev_q_sdev_q_mismatch += 1

        # Checks for qla2xxx bug for retry_delay RH BZ#1588133
        if (sdev.host.hostt.name in "qla2xxx" and 
            struct_exists("struct fc_port") and 
            (member_size("struct fc_port", "retry_delay_timestamp") != -1)):

            fc_port = readSU("struct fc_port", long(sdev.hostdata))

            if (fc_port):
                retry_delay_timestamp = readSU("struct fc_port", long(fc_port.retry_delay_timestamp))
            else:
                # If fc_port is NULL, then fetching the retry_delay_timestamp would result in crash,
                # so just mark retry_delay_timestamp to 0 and process next sdev and fc_port
                retry_delay_timestamp = 0

            if (retry_delay_timestamp != 0):
                retry_delay = (retry_delay_timestamp - jiffies)/1000/60
                if (retry_delay > 2):
                    dev_warnings += 1
                    print("ERROR:   scsi_device {:#x} ({}) has retry_delay_timestamp: {:d}, "
                          "IOs delayed for {:f} more minutes".format(sdev, get_scsi_device_id(sdev),
                          retry_delay_timestamp, retry_delay))
                    retry_delay_bug += 1

        # command checks
        cmd_warnings += run_cmd_checks(sdev)

    if (retry_delay_bug):
        print("\nERROR:   HBA driver returning 'SCSI_MLQUEUE_TARGET_BUSY' due to a large retry_delay.\n"
              "\t See https://patchwork.kernel.org/patch/10450567/")

    if (qla_cmd_abort_bug):
        print("\nERROR:   scsi_device.device_busy count is negative, this could be caused due to"
              "\t double completion of scsi_cmnd from qla2xxx_eh_abort.\n"
              "\t See https://patchwork.kernel.org/patch/10587997/")

    if (gendev_q_sdev_q_mismatch):
        print("\nNOTE:    The scsi_device->request_queue is not same as gendisk->request_queue\n"
              "\t for {} scsi device(s). \n\n"
              "\t It is likely that custom multipathing solutions have created 'gendisk',\n"
              "\t 'request_queue' structures which are not registered with kernel.\n"
              "\t *Although this may or may not be a reason for issue, but it could make\n"
              "\t the analysis of scsi_device, request_queue and gendisk struct confusing!\n"
              .format(gendev_q_sdev_q_mismatch))

    dev_warnings += cmd_warnings

    return (dev_warnings)

def run_target_checks():
    target_warnings = 0
    fc_rport_warnings = 0
    enum_starget_state = EnumInfo("enum scsi_target_state")
    supported_modules = ["lpfc", "qla2xxx", "fnic", "qedf", "zfcp"]

    for shost in get_scsi_hosts():
        if (shost.__targets.next != shost.__targets.next.next):
            for starget in readSUListFromHead(shost.__targets, "siblings", "struct scsi_target"):
                if (member_size("struct scsi_target", "target_busy") != -1):
                    try:
                        if (atomic_t(starget.target_busy) > 0):
                            target_warnings += 1
                            print("WARNING: scsi_target {:10s} {:x} is having non-zero "
                                "target_busy count: {:d}".format(starget.dev.kobj.name,
                                int(starget), atomic_t(starget.target_busy)))
                        if (atomic_t(starget.target_blocked) > 0):
                            target_warnings += 1
                            print("WARNING: scsi_target {:10s} {:x} is blocked "
                                "(target_blocked count: {:d})".format(starget.dev.kobj.name,
                                starget, atomic_t(starget.target_blocked)))
                        if (enum_starget_state.getnam(starget.state) != 'STARGET_RUNNING'):
                            target_warnings += 1
                            print("WARNING: scsi_target {:10s} {:x} not in RUNNING "
                                  "state".format(starget.dev.kobj.name, starget))
                        if (get_hostt_module_name(shost) in supported_modules):
                            enum_fcrport_state = EnumInfo("enum fc_port_state")
                            fc_rport = starget_to_rport(starget)
                            if (enum_fcrport_state.getnam(fc_rport.port_state) != 'FC_PORTSTATE_ONLINE'):
                                print("WARNING: FC rport (WWPN: {:x}) on {:10s} is in "
                                      "{} state".format(fc_rport.port_name, starget.dev.kobj.name,
                                      enum_fcrport_state.getnam(fc_rport.port_state)))
                                target_warnings += 1
                                fc_rport_warnings += 1

                    except KeyError:
                        pylog.warning("Error in processing scsi_target {:x},"
                                      "please check manually".format(int(starget)))

    if (fc_rport_warnings):
        print("Use '-f' to check detailed information about FC remote ports.\n")

    return target_warnings

def run_scsi_checks():
    host_warnings = 0
    dev_cmd_warnings = 0
    target_warnings = 0

    # scsi host checks
    host_warnings = run_host_checks()

    # scsi device and scsi command  checks
    dev_cmd_warnings = run_sdev_cmd_checks()

    # scsi_target checks
    target_warnings = run_target_checks()

    print ("\n### Summary:\n")
    print ("    Task                             Errors/Warnings")
    print ("    ------------------------------------------------")
    print ("    SCSI host checks:                {}". format(host_warnings))
    print ("    SCSI device, command checks:     {}". format(dev_cmd_warnings))
    print ("    SCSI target checks:              {}". format(target_warnings))

verbose = 0

if ( __name__ == '__main__'):

    import argparse
    parser =  argparse.ArgumentParser()

    parser.add_argument("-v", "--verbose", dest="Verbose", default = 0,
        action="count",
        help="verbose output")

    parser.add_argument("-p", "--proc", dest="proc_info", default = 0,
        action="store_true",
        help="show /proc/scsi/scsi style information")

    parser.add_argument("-d", "--devices", dest="devs", nargs='?',
                const="device_busy,sdev_state", default=0, metavar="FIELDS",
        help="show all devices")

    parser.add_argument("-s", "--hosts", dest="hosts", nargs='?',
                const="host_busy,host_failed", default=0, metavar="FIELDS",
        help="show all hosts")

    parser.add_argument("-T", "--Targets", dest="targets", nargs='?',
                const="target_busy", default=0, metavar="FIELDS",
        help="show all the scsi targets")

    parser.add_argument("-f", "--fcrports", dest="fcrports", nargs='?',
                const="port_state", default=0, metavar="FIELDS",
        help="show all the FC rports")

    parser.add_argument("-c", "--commands", dest="commands", nargs='?',
        const="jiffies_at_alloc", default=0, metavar="FIELDS",
        help="show SCSI commands")

    parser.add_argument("-q", "--queue", dest="queue", nargs='?',
        const="jiffies_at_alloc", default=0, metavar="FIELDS",
        help="show the IO requests, SCSI commands from request_queue")

    parser.add_argument("-r", "--requests", dest="requests", nargs='?',
        const="start_time,special", default=0, metavar="FIELDS",
        help="show requests to SCSI devices (INCOMPLETE)")

    parser.add_argument("-x", "--hex", dest="usehex", default = 0,
        action="store_true",
        help="display fields in hex")

    parser.add_argument("--check", dest="runcheck", default = 0,
        action="store_true",
        help="check for common SCSI issues")

    parser.add_argument("--time", dest="time", default = 0,
        action="store_true",
        help="display time and state information for  SCSI commands")

    parser.add_argument("--relative", dest="relative", nargs='?',
        const="jiffies", default=0,
        help="show fields relative to the given value/symbol.  Uses jiffies without argument")

    args = parser.parse_args()

    verbose = args.Verbose

    # Before doing anything else, check whether debuginfo is available!
    if (not scsi_debuginfo_OK()):
        sys.exit(0)

    if (args.runcheck):
        run_scsi_checks()

    if (args.proc_info):
        if (member_size("struct Scsi_Host", "host_busy") != -1):
            try:
                print_SCSI_devices()
            except crash.error as errval:
                print("print_SCSI_devices() failed: {}".format(errval))
        else:
            print("ERROR: command not supported without Scsi_Host->host_busy")

    if (args.commands or args.time):
        cmndcount = 0
        use_start_time_ns = member_size("struct request", "start_time") == -1
        for sdev in get_scsi_devices():
            cmndlist = get_scsi_commands(sdev)
            for cmnd in cmndlist:
                print_cmnd_header(cmnd)
                if (args.time):
                    if (cmnd.request):
                        display_command_time(cmnd, use_start_time_ns)
                    else:
                        print("\nWarning: cmnd.request is null for scsi_cmnd {:#x}. Skipping...".format(cmnd))

                if (args.commands):
                    display_fields(cmnd, args.commands, 
                               usehex=args.usehex,
                               relative=args.relative)
                else:
                    print("")
            cmndcount += len(cmndlist)
        if (not cmndcount):
            print("No SCSI commands found")

    if (args.devs):
        print_sdev_shost()

    if (args.targets):
        print_starget_shost()

    if (args.requests):
        display_requests(args.requests, args.usehex)

    if (args.queue):
        print_request_queue()

    if (args.fcrports):
        print_fcrports()

    if(args.hosts or not (args.runcheck or args.proc_info or args.devs or
       args.commands or args.requests or args.time or args.targets or
       args.queue or args.fcrports)):
        print_shost_info()
