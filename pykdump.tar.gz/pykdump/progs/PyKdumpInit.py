
# This script is run once when pykdump extension is loaded
#
# This can be used to register extra commands or anything else
# (C) Copyright 2006-2019 Hewlett Packard Enterprise Development LP


from crash import register_epython_prog as rprog

help = '''
The detailed documentation is available on the WEB. Here are most useful
options:

--summary
    prints a summary of connections and warnings about unusual situations

-iv
    prints information about interfaces

-a
    prints information about connections. You can use extra specifiers
    similar to 'netstat' command, e.g. choose TCP only by adding -t

--everything
    prints most things, useful for sending the output to someone with
    networking expertise
'''

rprog("xportshow",
      "Networking stuff",
      "-h   - list available options",
      help)


help = '''
The detailed documentation is available on the WEB. Here are most useful
options:

-q
    Run quietly printing WARNINGS if anything

-v
    Increase verbosity

--stacksummary
    print a categorized stack summary

--sysctl
    emulates 'sysctl -a' output
'''

rprog("crashinfo", "1st-pass analysis",
      "-h   - list available options",
      help)


help = '''
Print information about tasks in more details as the built-in 'ps'
command
'''

rprog("taskinfo", "Detailed info about tasks",
      "-h   - list available options",
      help)

help = '''
Print information about NFS subsystem, both client and server.
As NFS functionality is implemented in DLKMs, we need to access
debuginfo for some of these modules. Depending on kernel version
these modules are different. Sometimes just one or two files are
enough; sometimes we need four of them:
   "nfs", "lockd", "nfsd", "sunrpc".
On a live kernel they are found automatically. With vmcore, you
need to extract them and put in the same directory where vmcore
is located.
'''

rprog("nfsshow", "Information about NFS subsystem",
      "-h   - list available options",
      help)

help = '''
Print information about UNINTERRUPTIBLE threads.
This is mosly useful when you have a hang and many Un threads. This program
will try to categorize them - for example, PIDs of all processes waiting for
mutexes/sempahores.

WARNING:
--------
Algorithms for finding addresses of mutexes/sempahores are
kernel-dependent and as a result, they are not 100% reliable for some
kernels. Still, they are quite useful for many 'production'
distributions such as RHEL{6,7} and SLES11.
'''

rprog("hanginfo", "Information about hanging threads",
      "-h   - list available options",
      help)

help = '''
Decode and print information about subroutines registers and arguments,
as available from stack frames.

This is very useful when you are trying to find arguments of subroutines.
'''

rprog("fregs", "Decode and print stack frame registers",
      "-h   - list available options",
      help)

help = '''
If there are timestamps in dmesg buffer ('log' command output),
convert these timestams to date/time according to current TZ
and display result prepending this data to each line.
'''

rprog("tslog", "The same thing as 'log', but with real date/time",
      "-h   - list available options",
      help)

help = '''
Extract and display the information about SCSI adapter, scsi devices,
scsi commands from vmcore dumps. This command also provides
options to internally run some of the heuristics to determine common
problems with stuck scsi error handling, stalled commands etc.
'''

rprog("scsishow", "Display information about SCSI subsystem from"
      "vmcores", "-h   - list available options",
      help)

help = '''
Extract and display the information about multipath devices, LVM volumes
from vmcore dumps.
'''

rprog("dmshow", "Display information about multipath devices and"
      "LVM volumes", "-h   - list available options",
      help)


help = '''
Print process list in tree format.

-p          - Print process ID
-g          - Print number of threads
-s          - Print task state
-t          - Print a specific task and its children
'''

rprog("pstree", "Print process list in tree format",
        "-h   - list available options",
        help)

help = '''
Print information about DLKMs

  -h, --help            show this help message and exit
  --disasm=DISASM_MODULE
                        Disassemble a module functions
  --details=MODULE_DETAIL
                        Show details
  -t                    Shows tainted modules only
  -g                    Shows gaps between modules as well as phyiscally
                        allocated sizes
  -a                    Shows address range for the module
  -u                    Shows unloaded module data if possible
'''

rprog("modinfo", "Print information about DLKMs",
        "-h   - list available options",
        help)

help = '''
Print information about MD devices aka Linux Software RAID
usage: mdadm.py [-h] [-m] [-d]

optional arguments:
  -h, --help     show this help message and exit
  -m, --mddev    show mdamd_crash_format
  -d, --details  show mdadm_-D_format
'''

rprog("mdadm", "Print information about MD devices",
        "-h   - list available options",
        help)

help = '''
Show various addresses at different layers in the nvme*
modules.

usage: nvme.py [-h] [-l [NS]] [-c [CTRL]] [-n [NS]] [-d [CTRL]] [-q [CTRL]]
               [-i [QID]] [-s [SUB]] [-k]

optional arguments:
  -h, --help            show this help message and exit
  -l [NS], --list [NS]  list nvme namespaces vpd data and capacity
  -c [CTRL], --ctrl [CTRL]
                        show nvme controller information (nvme_ctrl)
  -n [NS], --ns [NS]    show nvme namespace information (nvme_ns)
  -d [CTRL], --dev [CTRL]
                        show nvme device information (nvme_dev,
                        nvme_loop_ctrl, nvme_rdma_ctrl, nvme_fc_ctrl)
  -q [CTRL], --queue [CTRL]
                        show nvme queue information (nvme_queue,
                        nvme_loop_queue, nvme_rdma_queue, nvme_fc_queue)
  -i [QID], --qid [QID]
                        limit output by QID. for use with -q
  -s [SUB], --subsystem [SUB]
                        show nvme subsystem information (nvme_subsystem)
  -k, --check           check for common NVMe issues
'''

rprog("nvme", "Print information about NVME",
        "-h   - list available options",
        help)
