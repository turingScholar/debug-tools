from __future__ import print_function

# --------------------------------------------------------------------
# (C) Copyright 2006-2015 Hewlett Packard Enterprise Development LP
#
# Author: Alex Sidorenko <asid@hpe.com>
#
# --------------------------------------------------------------------


"""PyKdump Python API for remote Dumpanalysis Tool
"""
# Version number
__version__ = '0.1'

