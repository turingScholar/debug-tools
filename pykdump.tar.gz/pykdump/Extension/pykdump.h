void use_python_sigint(void);
void use_crash_sigint(void);
