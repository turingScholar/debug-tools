
# A help subroutine to be called from epython.c to print some
# values defined in pykdump.API

# --------------------------------------------------------------------
# (C) Copyright 2020 Hewlett Packard Enterprise Development LP
#
# Author: Alex Sidorenko <asid@hpe.com>
#
# --------------------------------------------------------------------

from pykdump import API

API.__epythonOptions(1)

